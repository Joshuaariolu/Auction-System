import java.text.MessageFormat;
import java.util.*;

public class Auction
{
    private ArrayList<Item> items;
    private int _winningBid;

    public Auction()
    {
        items = new ArrayList<Item>();
        addItems();
    }

    private void addItems()
    {
        items.add(new Item(1,"Chair", "This is a chair"));
        items.add(new Item(2,"Table", "This is a Table"));
        items.add(new Item(3,"Bed", "This is a bed"));
        items.add(new Item(4,"Cupboard", "This is a cupboard"));
        items.add(new Item(5,"Piano", "This is a piano"));
    }

    public void getItems()
    {
        for ( Item item : items)
        {
            System.out.println(MessageFormat.format("Item Number: {0} | Item Name: {1} | Item Description: {2}",
                    item.getNumber(), item.getName(), item.getDescription()));
        }
    }


    public void placeBid(int itemNumber, Bid bidder, double amount)
    {
        boolean isItemNumberPresent = false;

        for ( Item item : items)
        {
            if (itemNumber == item.getNumber())
            {
                item.bidForItem(bidder, amount);
                isItemNumberPresent = true;
                break;
            }
        }

         if (isItemNumberPresent != true)
         {
             System.out.println("Error! Item number is not associated with any item on the list.");
         }
    }


    public void getItemBids(int itemNumber)
    {
        boolean isItemNumberPresent = false;

        for ( Item item : items)
        {
            if (itemNumber == item.getNumber())
            {
                item.getBidsForItem(itemNumber);
                isItemNumberPresent = true;
                break;
            }
        }

        if (isItemNumberPresent != true)
        {
            System.out.println("Error! Item number is not associated with any item on the list.");
        }
    }


    public void getItemWinningBid(double itemNumber)
    {
        boolean isItemNumberPresent = false;

        for ( Item item : items)
        {
            if (itemNumber == item.getNumber())
            {
                item.getWinningBid();
                isItemNumberPresent = true;
                break;
            }
        }

        if (isItemNumberPresent != true)
        {
            System.out.println("Error! Item number is not associated with any item on the list.");
        }
    }


    public void getItemWinningBidder(double itemNumber)
    {
        boolean isItemNumberPresent = false;

        for ( Item item : items)
        {
            if (itemNumber == item.getNumber())
            {
                item.getWinningBidderInfo();
                isItemNumberPresent = true;
                break;
            }
        }

        if (isItemNumberPresent != true)
        {
            System.out.println("Error! Item number is not associated with any item on the list.");
        }
    }









}
