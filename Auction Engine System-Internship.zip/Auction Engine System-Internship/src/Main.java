import java.util.*;

public class Main
{
    public static void main(String[] args)
    {
       /*
        Welcome to Auction House.
        Items to bid for are listed below:

        Item Number: 1 | Item Name: Chair | Item Description: This is a chair
        Item Number: 2 | Item Name: Table | Item Description: This is a Table
        Item Number: 3 | Item Name: Bed | Item Description: This is a bed
        Item Number: 4 | Item Name: Cupboard | Item Description: This is a cupboard
        Item Number: 5 | Item Name: Piano | Item Description: This is a piano
        */

        // create client profile (accepts String values (client name & client registration id) as parameter)
        Client c1 = new Client("Josh", "HE03");
        Client c2 = new Client("Uzo", "DS33");
        Client c3 = new Client("Abdul", "FG43");

        // register client to bid (accepts client Object as its parameter)
        Bid b1 = new Bid(c1);
        Bid b2 = new Bid(c2);
        Bid b3 = new Bid(c3);

        // start bidding
        Auction a1 = new Auction();

        //place bid on item(s) (accepts item number, bid Object and an amount(price) as  parameters)
        a1.placeBid(1,b1,2);
        a1.placeBid(1,b2,100);

//        a1.placeBid(2,b2,1);
//        a1.placeBid(2,b3,200);
//
//        a1.placeBid(3,b3,1.5);
//        a1.placeBid(3,b1,300.5);


        // gets the current winning bid for an item (accepts item number as its parameter)
        a1.getItemWinningBid(1);

        // gets all the bids for an item (accepts item number as its parameter)
        //a1.getItemBids(1);

        // gets the current winning bidder for an item (accepts item number as its parameter)
        //a1.getItemWinningBidder(1);


        // gets all the items which a bidder has bid for
        //b1.getItemsBidFor();






    }
}
