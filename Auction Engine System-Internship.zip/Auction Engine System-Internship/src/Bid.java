import java.text.MessageFormat;
import java.util.*;

public class Bid
{
    private Client _bidder;
    private ArrayList<Integer> _itemNumber;

    public Bid(Client bidder)
    {
        _bidder = bidder;
        _itemNumber = new ArrayList<Integer>();
    }


    public Client getBidder()
    {
        return _bidder;

    }


    public void setItemsBidFor(int itemNumber)
    {
        _itemNumber.add(itemNumber);
    }


    public void getItemsBidFor()
    {
        System.out.println(MessageFormat.format("Items bid for by (Name: {0} | Reg ID. {1}) are:",_bidder.getName(), _bidder.getRegID()));

        if(_itemNumber.isEmpty())
        {
            System.out.println("*No Items*");
            return;
        }

        TreeSet<Integer> treeSet = new TreeSet<Integer>();
        for (int i = 0; i < _itemNumber.size() ; i++)
        {
            treeSet.add(_itemNumber.get(i));
        }

        for (Integer out : treeSet)
        {
            System.out.println(MessageFormat.format("Item Number: {0}", out));
        }
    }


}

