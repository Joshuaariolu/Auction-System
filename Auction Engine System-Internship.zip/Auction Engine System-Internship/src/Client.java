public class Client
{
    private String _name;
    private String _regID;


    public Client(String name, String regID){
        _name = name;
        _regID = regID;
    }


    public String getName()
    {
        return _name;
    }


    public String getRegID() {

        return _regID;
    }
}
