import java.text.MessageFormat;
import java.util.*;

public class Item
{
    // private fields
    private int _number;
    private String _name;
    private String _description;

    private Bid _winningBidder;
    private double _winningBid;

    private List listOfBids;

    public Item () {}

    public Item (int number, String name, String description)
    {
        _number = number;
        _name = name;
        _description = description;
        listOfBids = new ArrayList();
    }


    public void bidForItem(Bid bidder, double amount)
    {
        if(amount < 1) {
            System.out.println("Reg ID: " + bidder.getBidder().getRegID() +
                    " (*Unsuccessful Bid*) - Sorry, but your bid must be £1 and above");
        }
        else if(_winningBidder == null) {
            _winningBid = amount;
            bidder.setItemsBidFor(getNumber());
            _winningBidder = bidder;
            listOfBids.add(amount);
            System.out.println("Reg ID: " + bidder.getBidder().getRegID() +
                    " (*Successful Bid*) - Congrats! You are the first bidder. Hope you win.");
        }
        else if(amount > _winningBid) {
            _winningBid = amount;
            bidder.setItemsBidFor(getNumber());
            _winningBidder = bidder;
            listOfBids.add(amount);
            System.out.println("Reg ID: " + bidder.getBidder().getRegID() +
                    " (*Successful Bid*) - Congrats! Your bid is the highest.");
        }
        else {
            System.out.println("Reg ID: " + bidder.getBidder().getRegID() +
                    " (*Unsuccessful Bid*) - Sorry, but your bid is lower than the highest bid");
        }
    }


    public void getBidsForItem(int itemNumber)
    {
        int num = 1;
        System.out.println("Bids for Item Number " + itemNumber + ":");

        for (Object bid: listOfBids)
        {
            System.out.println("Bid " + num++ + ": £" + bid);
        }

        if (listOfBids.isEmpty())
        {
            System.out.println("There are no bids for this item.");
        }
    }


    public void getWinningBid()
    {
        if(_winningBidder != null) {
            System.out.println(MessageFormat.format("Item Number: {0} | Winning Bid: £{1}",
                    _number,_winningBid));
        }
        else {
            System.out.println(MessageFormat.format("Item Number: {0} | Bid Status: *No Winning Bid*",
                    _number));
        }
    }


    public void getWinningBidderInfo()
    {
        if(_winningBidder != null)
        {
            System.out.println(MessageFormat.format("Item Number: {0} | Item Name: {1} | Item Description: {2} \n" +
                            "Winning Bid: £{3} | Client Name: {4} | Client Registration Number: {5}",
                    _number, _name, _description,_winningBid, _winningBidder.getBidder().getName(),
                    _winningBidder.getBidder().getRegID()));
        }
        else
            {
                System.out.println(MessageFormat.format("Item Number: {0} | Item Name: {1} | Item Description: {2} \n" +
                            "Bid Status: *No Winning Bidder*",_number, _name, _description));
        }
    }


    public int getNumber()
    {
        return _number;
    }


    public String getName()
    {
        return _name;
    }


    public String getDescription()
    {

        return _description;
    }

}
